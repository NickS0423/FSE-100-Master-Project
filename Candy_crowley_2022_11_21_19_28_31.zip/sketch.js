let chosenMenu;
let sizeGrowth1, sizeGrowth2, sizeGrowth3;
let circleX, circleY, circleSize;
let difficulty;
let circleCounter;
let lives;
let score;
let timerBarX;
let circleTimer;
let realTimer;
let start;
let otherDifficulty;
let gotWrong;
let size1, size2, size3, size4, size5, size6;
let randomSize;
// let x1, x2, x3, x4, x5;
// let y1, y2, y3, y4, y5;
let sizes;
let colors;
let colorsOther;
let color1, color2, color3, color4, color5, color6;
let trueColor;
let randomColor;
let question;
let isSquare;
let isSquare1, isSquare2, isSquare3, isSquare4, isSquare5, isSquare6, isSquare7;
let answer;

function setup() {
  createCanvas(500, 500);
  rectMode(CENTER);
  textAlign(CENTER);
  chosenMenu = 0;
  sizeGrowth1 = 0;
  sizeGrowth2 = 0;
  sizeGrowth3 = 0;
  circleX = 250;
  circleY = 300;
  timerBarX = 400;
  circleSize = 40;
  difficulty = 0;
  circleCounter = 0;
  score = 0;
  circleTimer = 300;
  realTimer = 300;
  start = false;
  otherDifficulty = 0;
  gotWrong = true;
  question = int(random(4));
  answer = int(random(6));
  isSquare = int(random(2));
  isSquare1 = int(random(2));
  isSquare2 = int(random(2));
  isSquare3 = int(random(2));
  isSquare4 = int(random(2));
  isSquare5 = int(random(2));
  isSquare6 = int(random(2));
  isSquare7 = int(random(2));
  colors = ['blue', 'yellow', 'red','green','orange', 'purple'];
  colorsOther = ['blue', 'yellow', 'red','green','orange', 'purple'];
  sizes = [10, 15, 20, 25, 30, 35];
  trueColor = 'blue';
  randomColor = random(colors);
  randomSize = random(30,70);
  color1 = random(colors);
  color2 = random(colors);
  color3 = random(colors);
  color4 = random(colors);
  color5 = random(colors);
  color6 = random(colors);
}

function draw() {
  if (chosenMenu == 0)
    {
      mainMenu();
    }
  else if (chosenMenu == 1)
    {
      game1();
    }
  else if (chosenMenu == 2)
    {
      game2();
    }
  else if (chosenMenu == 3)
    {
      game3();
    }
  else if (chosenMenu == 4)
    {
      gameOver();
    }
}

function mainMenu()
{
  background('#facade');
  strokeWeight(4);
  if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 115 && mouseY <= 185))
    {
      fill(0, 255, 0);
      if (sizeGrowth1 <5)
        {
          sizeGrowth1++;
        }
    }
  else
    {
      fill(255, 255, 255);
      if (sizeGrowth1 >0)
        {
          sizeGrowth1--;
        }
    }
  rect(390,150,140+sizeGrowth1,70+sizeGrowth1, 5);
  textSize(50+sizeGrowth1/2.5);
  fill(0);
  text('Skill', 390, 167);
  if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 215 && mouseY <= 285))
    {
      fill(0, 255, 0);
      if (sizeGrowth2 <5)
        {
          sizeGrowth2++;
        }
    }
  else
    {
      fill(255, 255, 255);
      if (sizeGrowth2 >0)
        {
          sizeGrowth2--;
        }
    }
  textSize(35+sizeGrowth2/2.5);
  rect(390, 250, 140+sizeGrowth2, 70+sizeGrowth2, 5);
  fill(0);
  text('Rhythm', 390, 260);
  if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 315 && mouseY <= 385))
    {
      fill(0, 255, 0);
      if (sizeGrowth3 <5)
        {
          sizeGrowth3++;
        }
    }
  else
    {
      fill(255, 255, 255);
      if (sizeGrowth3 >0)
        {
          sizeGrowth3--;
        }
    }
  textSize(40+sizeGrowth3/2.5);
  rect(390, 350, 140+sizeGrowth3, 70+sizeGrowth3, 5);
  fill(0);
  text('Puzzle', 390, 363);
}

function game1()
{
  if (lives <= 0)
    {
      chosenMenu = 4;
    }
  background('pink');
  timerBarX = (4*circleCounter/3);
  if (circleCounter <= 0)
    {
      spawnCircle();
      if (difficulty < 6)
      {
        circleCounter = 300 - (difficulty*30);
      }
      else
      {
        circleCounter = 90;
      }
        
      lives--;
    }
  fill('plum');
  switch(lives)
         {
           case 3:
             {
               rect(420,480,20,20);
             }
           case 2:
             {
               rect(450,480,20,20);
             }
           case 1:
             {
               rect(480,480,20,20);
             }
         }
  fill('lightgreen');
  rect(250,20,timerBarX,10);
  fill(255);
  text('Click the circle', 250,250);
  circleCounter--;
  // text(circleCounter, 250, 280);
  text(score, 35, 480);
  // text(difficulty, 250, 340);
  strokeWeight(4);
  fill(255);
  circle(circleX, circleY, circleSize*1.8);
}

function game2()
{
  if (lives <= 0)
    {
      chosenMenu = 4;
    }
  
  background('pink');
  fill(0);
  if (!start)
    {
      text('Press Circle\nto start', 250,100);
      if (gotWrong)
        fill('red');
      else
        fill('lightgreen');
    }
  else
    {
      text('Press Circle\nwhen it gets to 0', 250,100);
      if (Math.abs(0.3-realTimer/60)<=0.2)
        {
          fill('lightgreen');
        }
      else
        {
          fill('red');
        }
      if (difficulty < 5)
        circleTimer-=(1-difficulty*0.2);
      else
        circleTimer-=0.2;
      realTimer--;
    }
  
  circle(250, 300, 100);
  fill(0);
  switch(otherDifficulty)
    {
      case 0:
        {
          text((circleTimer/60).toFixed(0), 250, 220);
          break;
        }
      case 1:
        {
          if ((circleTimer/60).toFixed(0) > 1)
            {
              text((circleTimer/60).toFixed(0), 250, 220);
            }
          break;
        }
      case 2:
        {
          if ((circleTimer/60).toFixed(0) > 2)
            {
              text((circleTimer/60).toFixed(0), 250, 220);
            }
          break;
        }
      case 3:
        {
          if ((circleTimer/60).toFixed(0) > 3)
            {
              text((circleTimer/60).toFixed(0), 250, 220);
            }
          break;
        }
      case 4:
        {
          if ((circleTimer/60).toFixed(0) > 4)
            {
              text((circleTimer/60).toFixed(0), 250, 220);
            }
          break;
        }
      case 5:
        {
          if ((circleTimer/60).toFixed(0) > 5)
            {
              text((circleTimer/60).toFixed(0), 250, 220);
            }
          break;
        }
        
    }
  fill(0);
  // text(realTimer, 250, 400);
  // text(circleTimer, 250, 450);
  otherDifficulty = score%5;
  
  
  fill('plum');
  switch(lives)
         {
           case 3:
             {
               rect(420,480,20,20);
             }
           case 2:
             {
               rect(450,480,20,20);
             }
           case 1:
             {
               rect(480,480,20,20);
             }
         }
  fill(0);
  text(score, 35, 480);
}

function game3()
{
  if (lives <= 0)
    {
      chosenMenu = 4;
    }
  background('pink');
  timerBarX = (4*circleCounter/3);
  if (circleCounter <= 0)
    {
      buildLevel3();
      if (difficulty < 6)
      {
        circleCounter = 300 - (difficulty*30);
      }
      else
      {
        circleCounter = 90;
      }
        
      lives--;
    }
  fill('plum');
  switch(lives)
         {
           case 3:
             {
               rect(420,480,20,20);
             }
           case 2:
             {
               rect(450,480,20,20);
             }
           case 1:
             {
               rect(480,480,20,20);
             }
         }
  fill('lightgreen');
  rect(250,175,timerBarX,10);
  circleCounter--;
  // text(circleCounter, 250, 280);
  fill('black');
  text(score, 35, 480);
  fill("white");
  rect(120, 250, 100, 100);
  rect(250, 250, 100, 100);
  rect(380, 250, 100, 100);
  rect(120, 370, 100, 100);
  rect(250, 370, 100, 100);
  rect(380, 370, 100, 100);
  switch(answer)
    {
      case 0:
        {
          fill(color1);
          if (isSquare == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if (isSquare2 == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if (isSquare3 == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if (isSquare4 == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if (isSquare5 == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if (isSquare6 == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
      case 1:
        {
          fill(color1);
          if (isSquare1 == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if (isSquare == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if (isSquare3 == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if (isSquare4 == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if(isSquare5 == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if(isSquare6 == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
      case 2:
        {
          fill(color1);
          if(isSquare1 == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if(isSquare2 == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if (isSquare == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if(isSquare4 == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if(isSquare5 == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if(isSquare6 == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
      case 3:
        {
          fill(color1);
          if(isSquare1 == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if(isSquare2 == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if(isSquare3 == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if (isSquare == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if(isSquare5 == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if(isSquare6 == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
      case 4:
        {
          fill(color1);
          if(isSquare1 == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if(isSquare2 == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if(isSquare3 == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if(isSquare4 == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if (isSquare == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if(isSquare6 == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
      case 5:
        {
          fill(color1);
          if(isSquare1 == 0)
            rect(120, 250, size1, size1);
          else
            circle(120, 250, size1);
          fill(color2);
          if(isSquare2 == 0)
            rect(250, 250, size2, size2);
          else
            circle(250, 250, size2);
          fill(color3);
          if(isSquare3 == 0)
            rect(380, 250, size3, size3);
          else
            circle(380, 250, size3);
          fill(color4);
          if(isSquare4 == 0)
            rect(120, 370, size4, size4);
          else
            circle(120, 370, size4);
          fill(color5);
          if(isSquare5 == 0)
            rect(250, 370, size5, size5);
          else
            circle(250, 370, size5);
          fill(color6);
          if (isSquare == 0)
            rect(380, 370, size6, size6);
          else
            circle(380, 370, size6);
          break;
        }
    }
  fill('black');
  textSize(50);
  text("Click the", 250, 50);
  if (question == 0)
    {
      if (score < 11)
        {
          textSize(70);
        }
      else
        {
          textSize(randomSize);
        }
      text("largest", 250, 100);
    }
  else if (question == 1)
    {
      if (score < 11)
        {
          textSize(30);
        }
      else
        {
          textSize(randomSize);
        }
      text("smallest", 250, 100);
    }
  else
    {
      if (trueColor == 0)
        {
          if (score < 11)
            {
              fill('blue');
            }
          else
            {
              fill(randomColor);
            }
          text("blue", 250, 100);
        }
      else if (trueColor == 1)
        {
          if (score < 11)
            {
              fill('yellow');
            }
          else
            {
              fill(randomColor);
            }
          text("yellow", 250, 100);
        }
      else if (trueColor == 2)
        {
          if (score < 11)
            {
              fill('red');
            }
          else
            {
              fill(randomColor);
            }
          text("red", 250, 100);
        }
      else if (trueColor == 3)
        {
          if (score < 11)
            {
              fill('green');
            }
          else
            {
              fill(randomColor);
            }
          text("green", 250, 100);
        }
      else if (trueColor == 4)
        {
          if (score < 11)
            {
              fill('orange');
            }
          else
            {
              fill(randomColor);
            }
          text("orange", 250, 100);
        }
      else if (trueColor == 5)
        {
          if (score < 11)
            {
              fill('purple');
            }
          else
            {
              fill(randomColor);
            }
          text("purple", 250, 100);
        }
      
    }
  fill('black');
  textSize(50);
  if (isSquare == 0)
    {
      if (score < 11)
        {
          rect(150,137,20,20);
          rect(350,137,20,20);
        }
      else
        {
          if (isSquare7==0)
            {
              rect(150,137,20,20);
              rect(350,137,20,20);
            }
          else
            {
              circle(150,137,20);
              circle(350,137,20);
            }
        }
      text("square", 250, 150);
    }
  else
    {
      if (score < 11)
        {
          circle(170,137,20,20);
          circle(330,137,20,20);
        }
      else
        {
          if (isSquare7==0)
            {
              rect(170,137,20,20);
              rect(330,137,20,20);
            }
          else
            {
              circle(170,137,20);
              circle(330,137,20);
            }
        }
      text("circle", 250, 150);
    }
  
  // text(question,250,50);
  // text(answer,250,100);
  // text(trueColor,250,150);
  // text(isSquare, 250, 200);
  // text('game\n3', 250,250);
}

function buildLevel3()
{
  if (score%5==4)
    {
      difficulty++;
    }
  if (difficulty < 6)
    circleCounter = 300 - (difficulty*30);
  else
    circleCounter = 90
  answer = int(random(6));
  question = int(random(3));
  trueColor = int(random(6));
  isSquare = int(random(2));
  isSquare1 = int(random(2));
  isSquare2 = int(random(2));
  isSquare3 = int(random(2));
  isSquare4 = int(random(2));
  isSquare5 = int(random(2));
  isSquare6 = int(random(2));
  isSquare7 = int(random(2));
  colors = ['blue', 'yellow', 'red','green','orange', 'purple'];
  randomColor = random(colors);
  randomSize = random(30,70);
  switch(question)
    {
      case 0:
        {
          sizes = [10, 25, 40, 55, 70];
          size1 = random(sizes);
          size2 = random(sizes);
          size3 = random(sizes);
          size4 = random(sizes);
          size5 = random(sizes);
          size6 = random(sizes);
          color1 = random(colors);
          color2 = random(colors);
          color3 = random(colors);
          color4 = random(colors);
          color5 = random(colors);
          color6 = random(colors);
          switch(answer)
            {
              case 0:
                {
                  size1 = 85;
                  break;
                }
              case 1:
                {
                  size2 = 85;
                  break;
                }
              case 2:
                {
                  size3 = 85;
                  break;
                }
              case 3:
                {
                  size4 = 85;
                  break;
                }
              case 4:
                {
                  size5 = 85;
                  break;
                }
              case 5:
                {
                  size6 = 85;
                  break;
                }
            }
          break;
        }
      case 1:
        {
          sizes = [25, 40, 55, 70, 85];
          size1 = random(sizes);
          size2 = random(sizes);
          size3 = random(sizes);
          size4 = random(sizes);
          size5 = random(sizes);
          size6 = random(sizes);
          color1 = random(colors);
          color2 = random(colors);
          color3 = random(colors);
          color4 = random(colors);
          color5 = random(colors);
          color6 = random(colors);
          switch(answer)
            {
              case 0:
                {
                  size1 = 10;
                  break;
                }
              case 1:
                {
                  size2 = 10;
                  break;
                }
              case 2:
                {
                  size3 = 10;
                  break;
                }
              case 3:
                {
                  size4 = 10;
                  break;
                }
              case 4:
                {
                  size5 = 10;
                  break;
                }
              case 5:
                {
                  size6 = 10;
                  break;
                }
            }
          break;
        }
      case 2:
        {
          sizes = [10, 25, 40, 55, 70, 85];
          size1 = random(sizes);
          size2 = random(sizes);
          size3 = random(sizes);
          size4 = random(sizes);
          size5 = random(sizes);
          size6 = random(sizes);
          switch(trueColor)
            {
              case 0:
                {
                  colors = ['yellow', 'red','green','orange', 'purple'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'blue';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'blue';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'blue';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'blue';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'blue';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'blue';
                          break;
                        }
                    }
                  break;
                }
              case 1:
                {
                  colors = ['blue', 'red','green','orange', 'purple'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'yellow';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'yellow';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'yellow';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'yellow';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'yellow';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'yellow';
                          break;
                        }
                    }
                  break;
                }
              case 2:
                {
                  colors = ['blue', 'yellow','green','orange', 'purple'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'red';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'red';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'red';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'red';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'red';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'red';
                          break;
                        }
                    }
                  break;
                }
              case 3:
                {
                  colors = ['blue', 'red','yellow','orange', 'purple'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'green';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'green';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'green';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'green';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'green';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'green';
                          break;
                        }
                    }
                  break;
                }
              case 4:
                {
                  colors = ['blue', 'red','yellow','green', 'purple'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'orange';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'orange';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'orange';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'orange';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'orange';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'orange';
                          break;
                        }
                    }
                  break;
                }
              case 5:
                {
                  colors = ['blue', 'red','yellow','green', 'orange'];
                  color1 = random(colors);
                  color2 = random(colors);
                  color3 = random(colors);
                  color4 = random(colors);
                  color5 = random(colors);
                  color6 = random(colors);
                  if (isSquare != isSquare1)
                    {
                      color1 = random(colorsOther);
                    }
                  if (isSquare != isSquare2)
                    {
                      color2 = random(colorsOther);
                    }
                  if (isSquare != isSquare3)
                    {
                      color3 = random(colorsOther);
                    }
                  if (isSquare != isSquare4)
                    {
                      color4 = random(colorsOther);
                    }
                  if (isSquare != isSquare5)
                    {
                      color5 = random(colorsOther);
                    }
                  if (isSquare != isSquare6)
                    {
                      color6 = random(colorsOther);
                    }
                  switch(answer)
                    {
                      case 0:
                        {
                          color1 = 'purple';
                          break;
                        }
                      case 1:
                        {
                          color2 = 'purple';
                          break;
                        }
                      case 2:
                        {
                          color3 = 'purple';
                          break;
                        }
                      case 3:
                        {
                          color4 = 'purple';
                          break;
                        }
                      case 4:
                        {
                          color5 = 'purple';
                          break;
                        }
                      case 5:
                        {
                          color6 = 'purple';
                          break;
                        }
                    }
                  break;
                }
            }
        }
    }
}

function gameOver()
{
  background(220);
  fill(0);
  text('game over', 250,250);
  text('Score: '+score, 250,290);
}

function loseScreen(totalPoints, gameType)
{
  background(220);
  text('Game End\nTotal Points:'+totalePoints);
}

function spawnCircle()
{
  if (score%5==4)
    {
      difficulty++;
    }
  circleX = random(75, 425);
  circleY = random(75, 425);
  if (difficulty < 12)
    circleSize = 40-(difficulty*3);
  else
    circleSize = 2;
}

function mouseClicked()
{
  if (chosenMenu == 0)
    {
      if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 115 && mouseY <= 185))
      {
        chosenMenu = 1;
        circleCounter = 300;
        difficulty = 0;
        circleX = 250;
        circleY = 330
        circleSize = 40;
        lives = 3;
        score = 0;
      }
      else if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 215 && mouseY <= 285))
      {
        chosenMenu = 2;
        lives = 3;
        circleTimer = 360;
        realTimer = 360;
        difficulty = 0;
        otherDifficulty = 0;
        score = 0;
      }
      else if ((mouseX >= 320 && mouseX <= 460) && (mouseY >= 315 && mouseY <= 385))
      {
        chosenMenu = 3;
        buildLevel3();
        circleCounter = 300;
        difficulty = 0;
        lives = 3;
        score = 0;
      }
      
    }
  else if (chosenMenu == 1)
    {
      if (dist(mouseX, mouseY, circleX, circleY)<circleSize)
        {
          spawnCircle();
          if (difficulty < 6)
            circleCounter = 300 - (difficulty*30);
          else
            circleCounter = 90
          score++;
        }
      else
        {
          lives--;
        }
    }
  else if (chosenMenu == 2)
    {
      if (dist(mouseX, mouseY, 250, 300)<52)
        {
          if (!start)
            {
              start = true;
              circleTimer = 360;
              if (difficulty < 5)
                realTimer = 360 / (1-difficulty*0.2);
              else
                realTimer = 1800;
            }
          else
            {
              if (Math.abs(0.3-realTimer/60)<=0.2)
                {
                  start = false;
                  score++;
                  gotWrong = false;
                  if (score%5==0)
                    {
                      difficulty++;
                    }
                }
              else
                {
                  start = false;
                  lives--;
                  gotWrong = true;
                }
            }
        }
      else
        {
          lives--;
        }
      
    }
  else if (chosenMenu == 3)
    {
      switch (answer)
        {
          case 0:
            {
              if((mouseX >= 70 && mouseX <= 170) && (mouseY >= 200 && mouseY <= 300))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
          case 1:
            {
              if((mouseX >= 200 && mouseX <= 300) && (mouseY >= 200 && mouseY <= 300))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
          case 2:
            {
              if((mouseX >= 330 && mouseX <= 430) && (mouseY >= 200 && mouseY <= 300))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
          case 3:
            {
              if((mouseX >= 70 && mouseX <= 170) && (mouseY >= 320 && mouseY <= 420))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
          case 4:
            {
              if((mouseX >= 200 && mouseX <= 300) && (mouseY >= 320 && mouseY <= 420))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
          case 5:
            {
              if((mouseX >= 330 && mouseX <= 430) && (mouseY >= 320 && mouseY <= 420))
                {
                  score++;
                  buildLevel3();
                }
              else
                {
                  lives--;
                }
              break;
            }
        }
    }
  else if (chosenMenu == 4)
    {
      chosenMenu = 0;
    }
}
